package edu.neu.csye6200.classRoom;

public class ClassRoomView {

	public void addClassRoom(ClassRoom classRoom) {
		// TODO Auto-generated method stub
		
	}

	public void updateView() {
		// TODO Auto-generated method stub
		
	}
	
}
