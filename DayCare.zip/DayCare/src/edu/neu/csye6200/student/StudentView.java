package edu.neu.csye6200.student;

public class StudentView {

	public void updateView() {
		// TODO Auto-generated method stub
		
	}

}
